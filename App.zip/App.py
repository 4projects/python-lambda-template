import boto3
import requests
import uuid 

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('bus-data')


def handler(event, context):
    url = 'https://api.hrtb.us/api/buses/routes'
    r = requests.get(url)
    d = r.json()
    d['route'] = str(uuid.uuid4())
    table.put_item(Item=d)
    return 'OK'
